.mode csv
.import --skip 1 recover_v5_terms_seed.csv recover_v5_terms
.import --skip 1 recover_v5_confusions_seed.csv recover_v5_confusions
