# Recover V5 SQLite Lexicon Seed Pack

This package contains a small, license-safe seed lexicon for Recover V5 `Scored Legal Lexicon TopK Recall`.
It is **not** a full copy of any third-party lexicon. It is a schema-compatible starter set inspired by public resource categories previously discussed: Chinese spelling-correction confusion resources, pinyin dictionaries, and Rime-style input-method lexicons.

## Files

- `recover_v5_schema.sql` — SQLite schema for terms and confusions.
- `recover_v5_terms_seed.csv` — 134 scored legal terms.
- `recover_v5_confusions_seed.csv` — 20 starter ASR/confusion pairs.
- `recover_v5_import_sqlite.sql` — SQLite `.import` commands.

## Import

```bash
sqlite3 recover_v5_lexicon.db < recover_v5_schema.sql
sqlite3 recover_v5_lexicon.db < recover_v5_import_sqlite.sql
```

Run from the directory containing the CSV files.

## Notes

- `prior_score` is frozen to `[0,10]`.
- English/mixed terms use `token_type=en` and `normalized_pinyin` as lowercase exact token lookup key.
- V5 should use same-pinyin / exact-token TopK only by default. Near-pinyin remains disabled.
- This seed is intentionally small. Production quality depends on Lexicon Ops: adding domain terms, scores, and replay-derived confusion pairs.
