PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS recover_v5_terms (
  id TEXT PRIMARY KEY,
  word TEXT NOT NULL,
  pinyin TEXT NOT NULL,
  normalized_pinyin TEXT NOT NULL,
  term_length INTEGER NOT NULL CHECK(term_length BETWEEN 1 AND 32),
  prior_score REAL NOT NULL CHECK(prior_score >= 0 AND prior_score <= 10),
  frequency INTEGER DEFAULT 0,
  domain TEXT DEFAULT 'general',
  tags TEXT DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
  source TEXT DEFAULT 'manual_seed',
  token_type TEXT DEFAULT 'zh',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_recover_v5_terms_pinyin_len ON recover_v5_terms(normalized_pinyin, term_length, enabled, prior_score DESC);
CREATE INDEX IF NOT EXISTS idx_recover_v5_terms_domain ON recover_v5_terms(domain, enabled, prior_score DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_recover_v5_terms_word_domain ON recover_v5_terms(word, domain);

CREATE TABLE IF NOT EXISTS recover_v5_confusions (
  id TEXT PRIMARY KEY,
  observed TEXT NOT NULL,
  target TEXT NOT NULL,
  observed_pinyin TEXT DEFAULT '',
  target_pinyin TEXT DEFAULT '',
  score REAL NOT NULL CHECK(score >= 0 AND score <= 10),
  domain TEXT DEFAULT 'general',
  source TEXT DEFAULT 'manual_seed',
  enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_recover_v5_confusions_observed ON recover_v5_confusions(observed, enabled);
CREATE INDEX IF NOT EXISTS idx_recover_v5_confusions_target ON recover_v5_confusions(target, enabled);

CREATE VIEW IF NOT EXISTS recover_v5_topk_lookup AS
SELECT id, word, pinyin, normalized_pinyin, term_length, prior_score, domain, tags, token_type
FROM recover_v5_terms
WHERE enabled=1 AND prior_score IS NOT NULL;
